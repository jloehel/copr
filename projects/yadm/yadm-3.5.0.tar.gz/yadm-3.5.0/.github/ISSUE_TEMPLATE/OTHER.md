---
name: Other issue
about: Report issues with documentation, packaging, or something else
title: ''
labels: ''
assignees: ''

---
<!--
Before submitting, please search open and closed issues at
https://github.com/yadm-dev/yadm/issues to avoid duplication.
-->

### This issue is about

* [ ] Man pages or command-line usage
* [ ] Website documentation
* [ ] Packaging
* [ ] Other

### Describe the issue

[A clear and concise description of the issue.]
