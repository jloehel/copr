## Example of parsing `$YADM_HOOK_FULL_COMMAND`

Contributed by Tim Byrne

Hook    | Description
----    | -----------
pre_log | Provides an example of parsing `$YADM_HOOK_FULL_COMMAND` in Bash
